#include <iostream>
using namespace std;
int main() {
    int s[100], e[100];
    int n, k;           
    cout << "Enter the number of shops: ";
    cin >> n;
    cout << "Enter the start and end time of each shop:\n";
    for (int i = 0; i < n; i++) {
        cin >> s[i] >> e[i];
    }
    cout << "Enter the number of people : ";
    cin >> k;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (e[j] > e[j + 1]) {
             
                int temp = e[j];
                e[j] = e[j + 1];
                e[j + 1] = temp;
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }
    
    //122334556
    
    int end[100]; 
    for (int i = 0; i < k; i++) {
          end[i] = 0;
    }
    int count = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < k; j++) {
            if (end[j] <= s[i]) {
                end[j] = e[i];  
                count++;
                break; 
           }
        }
    }
    cout << "maximum number of shops that can be visited: " << count << endl;
    return 0;
}



